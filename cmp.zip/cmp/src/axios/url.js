export default {
    // 接口代理配置
    urlWeb: 'http://www.zjwocloud.cn/cucmp-web',
    urlUser: 'http://www.zjwocloud.cn/cucmp-user',
    urlEcs: 'http://www.zjwocloud.cn/cucmp-ecs'
}
